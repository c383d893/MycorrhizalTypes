# Main analyses for "Mycorrhizal Types Influence Island Biogeography of Plants"
# C. Delavaux et al. 2021

# Model version reported in text only, corresponding to model A in Tables SI 2-6
# Throughout this script, invasive = naturalized

# The analyses are run for EM:AM, EM:NM, AM:NM, ORC:NM, ORC:M
# For each comparison, the following models are run:
# 1. Broad: native and invasive
# 2. Environmental: mainland and island, native and invasive

# Load packages
library(ggplot2);library(lme4);library(lmerTest);library(spdep);library(ncf);library(ape);library(sjPlot);library(gridExtra);library(MuMIn);library(lsmeans)

##########################
##########################
########## EM/AM #########
##########################
##########################

##########################
###### BROAD MODELS ######
##########################

# Prepare data
simp<- read.table("data/Mega2_Broadcomp2&3.txt", header=TRUE)                                                                    # read data
simp<- simp[,c("entity_ID","myc1","myc2","myc3","myc4","latitude","geology", "area","elev_range","entity_class","native","myc")] # take columns of interest
simp<-simp[!simp$entity_class == "undetermined",]                                                                                # remove all undetermined entity_class/land types
simpI<-simp[simp$entity_class=="Island",]                                                                                        # extract islands
simpM<-simp[simp$entity_class=="Mainland",]                                                                                      # extract mainlands
simpI<-simpI[simpI$geology=="dev"|simpI$geology=="nondev",]                                                                      # extract only dev/nondev islands
simpI$elev_range[simpI$elev_range == 0]<- 1                                                                                      # make 0 elevations 1
simpI$elev_range[is.na(simpI$elev_range)] <- 1                                                                                   # make unknown elevations 1

# Join Island and Mainland, Rename entity_class2
simp<-rbind(simpI,simpM)
simp$entity_class2<-"mainland"
simp$entity_class2[simp$geology == "dev"]<- "oceanic"
simp$entity_class2[simp$geology == "nondev"]<-"nonoceanic"

# Add logcounts
simp$logcounts1<- log(simp$myc1+0.01)
simp$logcounts2<- log(simp$myc2+0.01)
simp$logcounts3<- log(simp$myc3+0.01)
simp$logcounts4<- log(simp$myc4+0.01)

# Remove zero occurences
simp<-simp[!(simp$myc1==0),]

# Create native and invasive versions
simpn<-simp[simp$native=="native",]
simpi<-simp[simp$native=="invasive",]

# Add species counts
species<-read.csv("data/MEGA2Species.csv", header=TRUE, sep=",")                # read data
species$X<-NULL                                                                 # remove col
species$status[species$native==1]<- "N"                                         # recode Native
species$status[species$naturalized==1]<- "I"                                    # recode Invasive
df<-as.data.frame(unique(species$entity_ID))                                    # extract unique locations

sprich<-tapply(species$entity_ID, list(species$entity_ID, species$status), sum) # group by entity class and sum
sprich<-as.data.frame(sprich)                                                   # change to dataframe
sprich$entity_ID<-rownames(sprich)                                              # add rownames sprich to col entity_ID

# Extract native and invasive counts, rename cols
sprichnat<-sprich[,c(2,3)]
sprichinv<-sprich[,c(1,3)]

colnames(sprichnat)<-c("sprich","entity_ID")
colnames(sprichinv)<-c("sprich","entity_ID")

# Extract myc type
simpn.EM<-simpn[simpn$myc=="EM",]
simpn.AM<-simpn[simpn$myc=="AM",]
simpi.EM<-simpi[simpi$myc=="EM",]
simpi.AM<-simpi[simpi$myc=="AM",]

# Merge by both entity_ID and native
simpn.spr.EM<-merge(simpn.EM,sprichnat, by="entity_ID", all.x=TRUE)
simpn.spr.AM<-merge(simpn.AM,sprichnat, by="entity_ID", all.x=TRUE)
simpn.spr<-rbind(simpn.spr.AM, simpn.spr.EM)

simpi.spr.EM<-merge(simpi.EM,sprichnat, by="entity_ID", all.x=TRUE)
simpi.spr.AM<-merge(simpi.AM,sprichnat, by="entity_ID", all.x=TRUE)
simpi.spr<-rbind(simpi.spr.AM, simpi.spr.EM)

# Transform and scale
simpn.spr$sprich <- scale(log10(simpn.spr$sprich+.01))
simpn.spr$area <-scale(log10((simpn.spr$area)+.01)) #log of area
simpn.spr$elev_range <- scale(log10(simpn.spr$elev_range+.01))
simpn.spr$abslatitude<-scale(abs(simpn.spr$latitude))

simpi.spr$sprich <- scale(log10(simpi.spr$sprich+.01))
simpi.spr$area <-scale(log10((simpi.spr$area)+.01)) #log of area
simpi.spr$elev_range <- scale(log10(simpi.spr$elev_range+.01))
simpi.spr$abslatitude<-scale(abs(simpi.spr$latitude))

#############################
#### AMEM1 BROAD NATIVE #####
#############################
m1N <- glmer(myc1~myc*entity_class2+abslatitude+area+elev_range+sprich+(1|entity_class2:entity_ID) +(1|entity_class2:entity_ID:myc),
             family = poisson, data = simpn.spr,glmerControl(optimizer = "bobyqa", optCtrl = list(maxfun = 100000))) 
summary(m1N) 

#############################
### AMEM1 BROAD INVASIVE ####
#############################
m1I <- glmer(myc1~myc*entity_class2 + sprich +latitude+area+elev_range+(1|entity_class2:entity_ID) +(1|entity_class2:entity_ID:myc),
             family = poisson, data = simpi.spr, glmerControl(optimizer = "bobyqa", optCtrl = list(maxfun = 100000))) 
summary(m1I) 

##############################
#### ENVIRONMENTAL MODELS ####
##############################

##########################
##### MAINLAND MODELS ####
##########################

# Prepare data
gdat<- read.table("data/Mega2_Drivers.txt")                                                          # read data
gdat<- gdat[,c("entity_ID","mycAM1","mycEM1","mycAM2","mycEM2","mycAM3","mycEM3","mycAM4","mycEM4",  # take columns of interest
               "area","elev_range","entity_class","native","longitude","latitude",
               "CHELSA_annual_Prec","CHELSA_annual_mean_Temp","Popdensity")]
gdatM<-gdat[gdat$entity_class=="Mainland",]                                                          # extract mainlands

# Make gdat only mainlands:
gdat<-gdatM

# Remove zero occurences
gdat<-gdat[!(gdat$mycAM1==0 |gdat$mycEM1==0),]

# Transform and scale:
gdat$area <-scale(log10((gdat$area) + .01)) #log of area
gdat$elev_range <- scale(log10(gdat$elev_range+.01))
gdat$CHELSA_annual_mean_Temp<-scale(gdat$CHELSA_annual_mean_Temp)
gdat$CHELSA_annual_Prec<-scale(gdat$CHELSA_annual_Prec)
gdat$abslatitude<-scale(abs(gdat$latitude))
gdat$squaredlat<-scale(abs(gdat$latitude)^2)

# Create native and invasive versions
gdatMnat<-gdat[gdat$native=="native",]
gdatMin<-gdat[gdat$native=="invasive",]

gdatMnat<-na.omit(gdatMnat)
gdatMin<-na.omit(gdatMin)

##########################
##### MAINLAND NATIVE ####
##########################

AMEM1gdatMnat <- glm(cbind(gdatMnat$mycEM1,gdatMnat$mycAM1) ~ area + abslatitude+squaredlat+
                       CHELSA_annual_Prec +CHELSA_annual_mean_Temp +elev_range, data = gdatMnat, family = binomial(link="logit"))
summary(AMEM1gdatMnat)

# check overdispersion
N <- nrow(gdatMnat)
p <- length(coef(AMEM1gdatMnat))
E1 <- resid(AMEM1gdatMnat, type = "pearson")
Dispersion <- sum(E1^2)/ (N-p)

# apply quasibinomial
qAMEM1gdatMnat <- glm(cbind(gdatMnat$mycEM1,gdatMnat$mycAM1) ~ area +abslatitude+squaredlat+
                        CHELSA_annual_Prec +CHELSA_annual_mean_Temp +elev_range, data = gdatMnat, family = quasibinomial(link="logit"))

# account for spatial autocorrelation
coords <- cbind(gdatMnat$longitude, gdatMnat$latitude)
matrix.dist = as.matrix(dist(cbind(gdatMnat$longitude, gdatMnat$latitude)))
matrix.dist[1:10, 1:10]
matrix.dist.inv <- 1/matrix.dist
matrix.dist.inv[1:10, 1:10]
diag(matrix.dist.inv) <- 0
matrix.dist.inv[1:10, 1:10]
nonsp_moranI = Moran.I(resid(qAMEM1gdatMnat), matrix.dist.inv)
myDist = 1000
rac <- autocov_dist(resid(qAMEM1gdatMnat), coords, nbs = myDist, type = "inverse", zero.policy = TRUE, style = "W", longlat=T) # longlat=T interprets myDist = 300 as 300 km.

sp_qAMEM1gdatMnat <- glm(cbind(gdatMnat$mycEM1,gdatMnat$mycAM1)~  area+abslatitude+squaredlat+
                           CHELSA_annual_Prec +CHELSA_annual_mean_Temp+elev_range+ rac, data = gdatMnat, family = binomial(link="logit"))
summary(sp_qAMEM1gdatMnat) 

##########################
### MAINLAND INVASIVE ####
##########################

AMEM1gdatMin <- glm(cbind(gdatMin$mycEM1,gdatMin$mycAM1) ~ area + abslatitude+squaredlat+
                       CHELSA_annual_Prec +CHELSA_annual_mean_Temp +elev_range, data = gdatMin, family = binomial(link="logit"))
summary(AMEM1gdatMin)

# check overdispersion
N <- nrow(gdatMin)
p <- length(coef(AMEM1gdatMin))
E1 <- resid(AMEM1gdatMin, type = "pearson")
Dispersion <- sum(E1^2)/ (N-p)

# apply quasibinomial
qAMEM1gdatMin <- glm(cbind(gdatMin$mycEM1,gdatMin$mycAM1) ~ area +abslatitude+squaredlat+
                        CHELSA_annual_Prec +CHELSA_annual_mean_Temp +elev_range, data = gdatMin, family = quasibinomial(link="logit"))

# account for spatial autocorrelation
coords <- cbind(gdatMin$longitude, gdatMin$latitude)
matrix.dist = as.matrix(dist(cbind(gdatMin$longitude, gdatMin$latitude)))
matrix.dist[1:10, 1:10]
matrix.dist.inv <- 1/matrix.dist
matrix.dist.inv[1:10, 1:10]
diag(matrix.dist.inv) <- 0
matrix.dist.inv[1:10, 1:10]
nonsp_moranI = Moran.I(resid(qAMEM1gdatMin), matrix.dist.inv)
myDist = 1000
rac <- autocov_dist(resid(qAMEM1gdatMin), coords, nbs = myDist, type = "inverse", zero.policy = TRUE, style = "W", longlat=T) # longlat=T interprets myDist = 300 as 300 km.

sp_qAMEM1gdatMin <- glm(cbind(gdatMin$mycEM1,gdatMin$mycAM1)~  area+abslatitude+squaredlat+
                           CHELSA_annual_Prec +CHELSA_annual_mean_Temp+elev_range+ rac, data = gdatMin, family = binomial(link="logit"))
summary(sp_qAMEM1gdatMin) 

##########################
###### ISLAND MODELS #####
##########################

# Prepare data
gdat<- read.table("data/Mega2_Drivers.txt")                                                                       # read data
gdat<- gdat[,c("entity_ID","mycAM1","mycEM1","mycAM2","mycEM2","mycAM3","mycEM3","mycAM4","mycEM4",               # take columns of interest
               "latitude","longitude","geology", "area","elev_range","dist","age_Ma","entity_class","native",
               "CHELSA_annual_Prec","CHELSA_annual_mean_Temp","Popdensity")]
gdatI<-gdat[gdat$entity_class=="Island",]                                                                         # extract islands
gdatM<-gdat[gdat$entity_class=="Mainland",]                                                                       # extract mainlands

gdatI<-gdatI[gdatI$geology=="dev",]                                                                               # keep only oceanic islands

gdatI$elev_range[gdatI$elev_range == 0]<- 1                                                                       # make 0 elevations 1
gdatI$elev_range[is.na(gdatI$elev_range)] <- 1                                                                    # make unknown elevations 1

# Make gdat only islands:
gdat<-gdatI

# Remove zero occurences
gdat<-gdat[!(gdat$mycAM1==0 |gdat$mycEM1==0),]

# Transform and scale
gdat$area <-scale(log10(gdat$area + .01)) #log of area
gdat$dist<-scale(gdat$dist)
gdat$elev_range <- scale(log10(gdat$elev_range+.01))
gdat$age_Ma <- scale(log10(gdat$age_Ma+.01))
gdat$CHELSA_annual_mean_Temp<-scale(gdat$CHELSA_annual_mean_Temp)
gdat$CHELSA_annual_Prec<-scale(gdat$CHELSA_annual_Prec)
gdat$abslatitude<-scale(abs(gdat$latitude))
gdat$squaredlat<-scale(abs(gdat$latitude)^2)

# Create native and invasive versions
gdatInat<-gdat[gdat$native=="native",]
gdatIin<-gdat[gdat$native=="invasive",]

gdatInat<-na.omit(gdatInat)
gdatIin<-na.omit(gdatIin)

##########################
###### ISLAND NATIVE #####
##########################

AMEM1gdatInat.noage <- glm(cbind(gdatInat$mycEM1,gdatInat$mycAM1) ~  area +  dist+CHELSA_annual_Prec +abslatitude+squaredlat+
                             CHELSA_annual_mean_Temp +elev_range, data = gdatInat, family = binomial(link="logit"))
summary(AMEM1gdatInat.noage) 

# check overdispersion
N <- nrow(gdatInat)
p <- length(coef(AMEM1gdatInat.noage))
E1 <- resid(AMEM1gdatInat.noage, type = "pearson")
Dispersion <- sum(E1^2)/ (N-p)

# apply quasibinomial
qAMEM1gdatInat.noage <- glm(cbind(gdatInat$mycEM1,gdatInat$mycAM1) ~   area + dist+ CHELSA_annual_Prec+abslatitude+squaredlat+
                              CHELSA_annual_mean_Temp +elev_range, data = gdatInat, family = quasibinomial(link="logit"))
summary(qAMEM1gdatInat.noage) 
# account for spatial autocorrelation
coords <- cbind(gdatInat$longitude, gdatInat$latitude)
matrix.dist = as.matrix(dist(cbind(gdatInat$longitude, gdatInat$latitude)))
matrix.dist[1:10, 1:10]
matrix.dist.inv <- 1/matrix.dist
matrix.dist.inv[1:10, 1:10]
diag(matrix.dist.inv) <- 0
matrix.dist.inv[1:10, 1:10]
nonsp_moranI = Moran.I(resid(qAMEM1gdatInat.noage), matrix.dist.inv)
myDist = 1000
rac <- autocov_dist(resid(qAMEM1gdatInat.noage), coords, nbs = myDist, type = "inverse", zero.policy = TRUE, style = "W", longlat=T) # longlat=T interprets myDist = 300 as 300 km.
sp_qAMEM1gdatInat.noage <- glm(cbind(gdatInat$mycEM1,gdatInat$mycAM1)~  area + dist+ CHELSA_annual_Prec+abslatitude+squaredlat+
                                 CHELSA_annual_mean_Temp +elev_range+ rac, data = gdatInat, family = binomial(link="logit"))
summary(sp_qAMEM1gdatInat.noage)

##########################
#### ISLAND INVASIVE #####
##########################

AMEM1gdatIin.noage <- glm(cbind(gdatIin$mycEM1,gdatIin$mycAM1) ~  area +  dist+CHELSA_annual_Prec +abslatitude+squaredlat+
                             CHELSA_annual_mean_Temp +elev_range, data = gdatIin, family = binomial(link="logit"))
summary(AMEM1gdatIin.noage) 

# check overdispersion
N <- nrow(gdatIin)
p <- length(coef(AMEM1gdatIin.noage))
E1 <- resid(AMEM1gdatIin.noage, type = "pearson")
Dispersion <- sum(E1^2)/ (N-p)

# apply quasibinomial
qAMEM1gdatIin.noage <- glm(cbind(gdatIin$mycEM1,gdatIin$mycAM1) ~   area + dist+ CHELSA_annual_Prec+abslatitude+squaredlat+
                              CHELSA_annual_mean_Temp +elev_range, data = gdatIin, family = quasibinomial(link="logit"))
summary(qAMEM1gdatIin.noage) 
# account for spatial autocorrelation
coords <- cbind(gdatIin$longitude, gdatIin$latitude)
matrix.dist = as.matrix(dist(cbind(gdatIin$longitude, gdatIin$latitude)))
matrix.dist[1:10, 1:10]
matrix.dist.inv <- 1/matrix.dist
matrix.dist.inv[1:10, 1:10]
diag(matrix.dist.inv) <- 0
matrix.dist.inv[1:10, 1:10]
nonsp_moranI = Moran.I(resid(qAMEM1gdatIin.noage), matrix.dist.inv)
myDist = 1000
rac <- autocov_dist(resid(qAMEM1gdatIin.noage), coords, nbs = myDist, type = "inverse", zero.policy = TRUE, style = "W", longlat=T) # longlat=T interprets myDist = 300 as 300 km.
sp_qAMEM1gdatIin.noage <- glm(cbind(gdatIin$mycEM1,gdatIin$mycAM1)~  area + dist+ CHELSA_annual_Prec+abslatitude+squaredlat+
                                 CHELSA_annual_mean_Temp +elev_range+ rac, data = gdatIin, family = binomial(link="logit"))
summary(sp_qAMEM1gdatIin.noage)

##########################
##########################
########## EM/NM #########
##########################
##########################

##########################
###### BROAD MODELS ######
##########################

# Prepare data
simp<- read.table("data/Mega2_Broadcomp2&3.ECMvsNM.txt", header=TRUE)                                                                    # read data
simp<- simp[,c("entity_ID","myc1","myc2","myc3","myc4","latitude","geology", "area","elev_range","entity_class","native","myc")] # take columns of interest
simp<-simp[!simp$entity_class == "undetermined",]                                                                                # remove all undetermined entity_class/land types
simpI<-simp[simp$entity_class=="Island",]                                                                                        # extract islands
simpM<-simp[simp$entity_class=="Mainland",]                                                                                      # extract mainlands
simpI<-simpI[simpI$geology=="dev"|simpI$geology=="nondev",]                                                                      # extract only dev/nondev islands
simpI$elev_range[simpI$elev_range == 0]<- 1                                                                                      # make 0 elevations 1
simpI$elev_range[is.na(simpI$elev_range)] <- 1                                                                                   # make unknown elevations 1

# Join Island and Mainland, Rename entity_class2
simp<-rbind(simpI,simpM)
simp$entity_class2<-"mainland"
simp$entity_class2[simp$geology == "dev"]<- "oceanic"
simp$entity_class2[simp$geology == "nondev"]<-"nonoceanic"

# Add logcounts
simp$logcounts1<- log(simp$myc1+0.01)
simp$logcounts2<- log(simp$myc2+0.01)
simp$logcounts3<- log(simp$myc3+0.01)
simp$logcounts4<- log(simp$myc4+0.01)

# Remove zero occurences
simp<-simp[!(simp$myc1==0),]

# Create native and invasive versions
simpn<-simp[simp$native=="native",]
simpi<-simp[simp$native=="invasive",]

# Add species counts
species<-read.csv("data/MEGA2Species.csv", header=TRUE, sep=",")                # read data
species$X<-NULL                                                                 # remove col
species$status[species$native==1]<- "N"                                         # recode Native
species$status[species$naturalized==1]<- "I"                                    # recode Invasive
df<-as.data.frame(unique(species$entity_ID))                                    # extract unique locations

sprich<-tapply(species$entity_ID, list(species$entity_ID, species$status), sum) # group by entity class and sum
sprich<-as.data.frame(sprich)                                                   # change to dataframe
sprich$entity_ID<-rownames(sprich)                                              # add rownames sprich to col entity_ID

# Extract native and invasive counts, rename cols
sprichnat<-sprich[,c(2,3)]
sprichinv<-sprich[,c(1,3)]

colnames(sprichnat)<-c("sprich","entity_ID")
colnames(sprichinv)<-c("sprich","entity_ID")

# Extract myc type
simpn.EM<-simpn[simpn$myc=="EM",]
simpn.NM<-simpn[simpn$myc=="NM",]
simpi.EM<-simpi[simpi$myc=="EM",]
simpi.NM<-simpi[simpi$myc=="NM",]

# Merge by both entity_ID and native
simpn.spr.EM<-merge(simpn.EM,sprichnat, by="entity_ID", all.x=TRUE)
simpn.spr.NM<-merge(simpn.NM,sprichnat, by="entity_ID", all.x=TRUE)
simpn.spr<-rbind(simpn.spr.NM, simpn.spr.EM)

simpi.spr.EM<-merge(simpi.EM,sprichnat, by="entity_ID", all.x=TRUE)
simpi.spr.NM<-merge(simpi.NM,sprichnat, by="entity_ID", all.x=TRUE)
simpi.spr<-rbind(simpi.spr.NM, simpi.spr.EM)

# Transform and scale
simpn.spr$sprich <- scale(log10(simpn.spr$sprich+.01))
simpn.spr$area <-scale(log10((simpn.spr$area)+.01)) #log of area
simpn.spr$elev_range <- scale(log10(simpn.spr$elev_range+.01))
simpn.spr$abslatitude<-scale(abs(simpn.spr$latitude))

simpi.spr$sprich <- scale(log10(simpi.spr$sprich+.01))
simpi.spr$area <-scale(log10((simpi.spr$area)+.01)) #log of area
simpi.spr$elev_range <- scale(log10(simpi.spr$elev_range+.01))
simpi.spr$abslatitude<-scale(abs(simpi.spr$latitude))

#############################
#### EMNM1 BROAD NATIVE #####
#############################
m1N <- glmer(myc1~myc*entity_class2+abslatitude+area+elev_range+sprich+(1|entity_class2:entity_ID) +(1|entity_class2:entity_ID:myc),
             family = poisson, data = simpn.spr,glmerControl(optimizer = "bobyqa", optCtrl = list(maxfun = 100000))) 
summary(m1N) 

#############################
### EMNM1 BROAD INVASIVE ####
#############################
m1I <- glmer(myc1~myc*entity_class2 + sprich +latitude+area+elev_range+(1|entity_class2:entity_ID) +(1|entity_class2:entity_ID:myc),
             family = poisson, data = simpi.spr, glmerControl(optimizer = "bobyqa", optCtrl = list(maxfun = 100000))) 
summary(m1I) 

##############################
#### ENVIRONMENTAL MODELS ####
##############################

##########################
##### MAINLAND MODELS ####
##########################

# Prepare data
gdat<- read.table("data/Mega2_Drivers.ECMvsNM.txt")                                                          # read data
gdat<- gdat[,c("entity_ID","mycNM1","mycEM1","mycNM2","mycEM2","mycNM3","mycEM3","mycNM4","mycEM4",  # take columns of interest
               "area","elev_range","entity_class","native","longitude","latitude",
               "CHELSA_annual_Prec","CHELSA_annual_mean_Temp","Popdensity")]
gdatM<-gdat[gdat$entity_class=="Mainland",]                                                          # extract mainlands

# Make gdat only mainlands:
gdat<-gdatM

# Remove zero occurences
gdat<-gdat[!(gdat$mycEM1==0 |gdat$mycNM1==0),]

# Transform and scale:
gdat$area <-scale(log10((gdat$area) + .01)) #log of area
gdat$elev_range <- scale(log10(gdat$elev_range+.01))
gdat$CHELSA_annual_mean_Temp<-scale(gdat$CHELSA_annual_mean_Temp)
gdat$CHELSA_annual_Prec<-scale(gdat$CHELSA_annual_Prec)
gdat$abslatitude<-scale(abs(gdat$latitude))
gdat$squaredlat<-scale(abs(gdat$latitude)^2)

# Create native and invasive versions
gdatMnat<-gdat[gdat$native=="native",]
gdatMin<-gdat[gdat$native=="invasive",]

gdatMnat<-na.omit(gdatMnat)
gdatMin<-na.omit(gdatMin)

##########################
##### MAINLAND NATIVE ####
##########################

EMNM1gdatMnat <- glm(cbind(gdatMnat$mycEM1,gdatMnat$mycNM1) ~ area + abslatitude+squaredlat+
                       CHELSA_annual_Prec +CHELSA_annual_mean_Temp +elev_range, data = gdatMnat, family = binomial(link="logit"))
summary(EMNM1gdatMnat)

# check overdispersion
N <- nrow(gdatMnat)
p <- length(coef(EMNM1gdatMnat))
E1 <- resid(EMNM1gdatMnat, type = "pearson")
Dispersion <- sum(E1^2)/ (N-p)

# apply quasibinomial
qEMNM1gdatMnat <- glm(cbind(gdatMnat$mycEM1,gdatMnat$mycNM1) ~ area +abslatitude+squaredlat+
                        CHELSA_annual_Prec +CHELSA_annual_mean_Temp +elev_range, data = gdatMnat, family = quasibinomial(link="logit"))

# account for spatial autocorrelation
coords <- cbind(gdatMnat$longitude, gdatMnat$latitude)
matrix.dist = as.matrix(dist(cbind(gdatMnat$longitude, gdatMnat$latitude)))
matrix.dist[1:10, 1:10]
matrix.dist.inv <- 1/matrix.dist
matrix.dist.inv[1:10, 1:10]
diag(matrix.dist.inv) <- 0
matrix.dist.inv[1:10, 1:10]
nonsp_moranI = Moran.I(resid(qEMNM1gdatMnat), matrix.dist.inv)
myDist = 1000
rac <- autocov_dist(resid(qEMNM1gdatMnat), coords, nbs = myDist, type = "inverse", zero.policy = TRUE, style = "W", longlat=T) # longlat=T interprets myDist = 300 as 300 km.

sp_qEMNM1gdatMnat <- glm(cbind(gdatMnat$mycEM1,gdatMnat$mycNM1)~  area+abslatitude+squaredlat+
                           CHELSA_annual_Prec +CHELSA_annual_mean_Temp+elev_range+ rac, data = gdatMnat, family = binomial(link="logit"))
summary(sp_qEMNM1gdatMnat) 

##########################
### MAINLAND INVASIVE ####
##########################

EMNM1gdatMin <- glm(cbind(gdatMin$mycEM1,gdatMin$mycNM1) ~ area + abslatitude+squaredlat+
                      CHELSA_annual_Prec +CHELSA_annual_mean_Temp +elev_range, data = gdatMin, family = binomial(link="logit"))
summary(EMNM1gdatMin)

# check overdispersion
N <- nrow(gdatMin)
p <- length(coef(EMNM1gdatMin))
E1 <- resid(EMNM1gdatMin, type = "pearson")
Dispersion <- sum(E1^2)/ (N-p)

# apply quasibinomial
qEMNM1gdatMin <- glm(cbind(gdatMin$mycEM1,gdatMin$mycNM1) ~ area +abslatitude+squaredlat+
                       CHELSA_annual_Prec +CHELSA_annual_mean_Temp +elev_range, data = gdatMin, family = quasibinomial(link="logit"))

# account for spatial autocorrelation
coords <- cbind(gdatMin$longitude, gdatMin$latitude)
matrix.dist = as.matrix(dist(cbind(gdatMin$longitude, gdatMin$latitude)))
matrix.dist[1:10, 1:10]
matrix.dist.inv <- 1/matrix.dist
matrix.dist.inv[1:10, 1:10]
diag(matrix.dist.inv) <- 0
matrix.dist.inv[1:10, 1:10]
nonsp_moranI = Moran.I(resid(qEMNM1gdatMin), matrix.dist.inv)
myDist = 1000
rac <- autocov_dist(resid(qEMNM1gdatMin), coords, nbs = myDist, type = "inverse", zero.policy = TRUE, style = "W", longlat=T) # longlat=T interprets myDist = 300 as 300 km.

sp_qEMNM1gdatMin <- glm(cbind(gdatMin$mycEM1,gdatMin$mycNM1)~  area+abslatitude+squaredlat+
                          CHELSA_annual_Prec +CHELSA_annual_mean_Temp+elev_range+ rac, data = gdatMin, family = binomial(link="logit"))
summary(sp_qEMNM1gdatMin) 

##########################
###### ISLAND MODELS #####
##########################

# Prepare data
gdat<- read.table("data/Mega2_Drivers.ECMvsNM.txt")                                                                       # read data
gdat<- gdat[,c("entity_ID","mycNM1","mycEM1","mycNM2","mycEM2","mycNM3","mycEM3","mycNM4","mycEM4",               # take columns of interest
               "latitude","longitude","geology", "area","elev_range","dist","age_Ma","entity_class","native",
               "CHELSA_annual_Prec","CHELSA_annual_mean_Temp","Popdensity")]
gdatI<-gdat[gdat$entity_class=="Island",]                                                                         # extract islands
gdatM<-gdat[gdat$entity_class=="Mainland",]                                                                       # extract mainlands

gdatI<-gdatI[gdatI$geology=="dev",]                                                                               # keep only oceanic islands

gdatI$elev_range[gdatI$elev_range == 0]<- 1                                                                       # make 0 elevations 1
gdatI$elev_range[is.na(gdatI$elev_range)] <- 1                                                                    # make unknown elevations 1

# Make gdat only islands:
gdat<-gdatI

# Remove zero occurences
gdat<-gdat[!(gdat$mycNM1==0 |gdat$mycEM1==0),]

# Transform and scale
gdat$area <-scale(log10(gdat$area + .01)) #log of area
gdat$dist<-scale(gdat$dist)
gdat$elev_range <- scale(log10(gdat$elev_range+.01))
gdat$age_Ma <- scale(log10(gdat$age_Ma+.01))
gdat$CHELSA_annual_mean_Temp<-scale(gdat$CHELSA_annual_mean_Temp)
gdat$CHELSA_annual_Prec<-scale(gdat$CHELSA_annual_Prec)
gdat$abslatitude<-scale(abs(gdat$latitude))
gdat$squaredlat<-scale(abs(gdat$latitude)^2)

# Create native and invasive versions
gdatInat<-gdat[gdat$native=="native",]
gdatIin<-gdat[gdat$native=="invasive",]

gdatInat<-na.omit(gdatInat)
gdatIin<-na.omit(gdatIin)

##########################
###### ISLAND NATIVE #####
##########################

EMNM1gdatInat.noage <- glm(cbind(gdatInat$mycEM1,gdatInat$mycNM1) ~  area +  dist+CHELSA_annual_Prec +abslatitude+squaredlat+
                             CHELSA_annual_mean_Temp +elev_range, data = gdatInat, family = binomial(link="logit"))
summary(EMNM1gdatInat.noage) 

# check overdispersion
N <- nrow(gdatInat)
p <- length(coef(EMNM1gdatInat.noage))
E1 <- resid(EMNM1gdatInat.noage, type = "pearson")
Dispersion <- sum(E1^2)/ (N-p)

# apply quasibinomial
qEMNM1gdatInat.noage <- glm(cbind(gdatInat$mycEM1,gdatInat$mycNM1) ~   area + dist+ CHELSA_annual_Prec+abslatitude+squaredlat+
                              CHELSA_annual_mean_Temp +elev_range, data = gdatInat, family = quasibinomial(link="logit"))
summary(qEMNM1gdatInat.noage) 
# account for spatial autocorrelation
coords <- cbind(gdatInat$longitude, gdatInat$latitude)
matrix.dist = as.matrix(dist(cbind(gdatInat$longitude, gdatInat$latitude)))
matrix.dist[1:10, 1:10]
matrix.dist.inv <- 1/matrix.dist
matrix.dist.inv[1:10, 1:10]
diag(matrix.dist.inv) <- 0
matrix.dist.inv[1:10, 1:10]
nonsp_moranI = Moran.I(resid(qEMNM1gdatInat.noage), matrix.dist.inv)
myDist = 1000
rac <- autocov_dist(resid(qEMNM1gdatInat.noage), coords, nbs = myDist, type = "inverse", zero.policy = TRUE, style = "W", longlat=T) # longlat=T interprets myDist = 300 as 300 km.
sp_qEMNM1gdatInat.noage <- glm(cbind(gdatInat$mycEM1,gdatInat$mycNM1)~  area + dist+ CHELSA_annual_Prec+abslatitude+squaredlat+
                                 CHELSA_annual_mean_Temp +elev_range+ rac, data = gdatInat, family = binomial(link="logit"))
summary(sp_qEMNM1gdatInat.noage)

##########################
#### ISLAND INVASIVE #####
##########################

EMNM1gdatIin.noage <- glm(cbind(gdatIin$mycEM1,gdatIin$mycNM1) ~  area +  dist+CHELSA_annual_Prec +abslatitude+squaredlat+
                            CHELSA_annual_mean_Temp +elev_range, data = gdatIin, family = binomial(link="logit"))
summary(EMNM1gdatIin.noage) 

# check overdispersion
N <- nrow(gdatIin)
p <- length(coef(EMNM1gdatIin.noage))
E1 <- resid(EMNM1gdatIin.noage, type = "pearson")
Dispersion <- sum(E1^2)/ (N-p)

# apply quasibinomial
qEMNM1gdatIin.noage <- glm(cbind(gdatIin$mycEM1,gdatIin$mycNM1) ~   area + dist+ CHELSA_annual_Prec+abslatitude+squaredlat+
                             CHELSA_annual_mean_Temp +elev_range, data = gdatIin, family = quasibinomial(link="logit"))
summary(qEMNM1gdatIin.noage) 
# account for spatial autocorrelation
coords <- cbind(gdatIin$longitude, gdatIin$latitude)
matrix.dist = as.matrix(dist(cbind(gdatIin$longitude, gdatIin$latitude)))
matrix.dist[1:10, 1:10]
matrix.dist.inv <- 1/matrix.dist
matrix.dist.inv[1:10, 1:10]
diag(matrix.dist.inv) <- 0
matrix.dist.inv[1:10, 1:10]
nonsp_moranI = Moran.I(resid(qEMNM1gdatIin.noage), matrix.dist.inv)
myDist = 1000
rac <- autocov_dist(resid(qEMNM1gdatIin.noage), coords, nbs = myDist, type = "inverse", zero.policy = TRUE, style = "W", longlat=T) # longlat=T interprets myDist = 300 as 300 km.
sp_qEMNM1gdatIin.noage <- glm(cbind(gdatIin$mycEM1,gdatIin$mycNM1)~  area + dist+ CHELSA_annual_Prec+abslatitude+squaredlat+
                                CHELSA_annual_mean_Temp +elev_range+ rac, data = gdatIin, family = binomial(link="logit"))
summary(sp_qEMNM1gdatIin.noage)

##########################
##########################
########## AM/NM #########
##########################
##########################

##########################
###### BROAD MODELS ######
##########################

# Prepare data
simp<- read.table("data/Mega2_Broadcomp2&3.AMvsNM.txt", header=TRUE)                                                                    # read data
simp<- simp[,c("entity_ID","myc1","myc2","myc3","myc4","latitude","geology", "area","elev_range","entity_class","native","myc")] # take columns of interest
simp<-simp[!simp$entity_class == "undetermined",]                                                                                # remove all undetermined entity_class/land types
simpI<-simp[simp$entity_class=="Island",]                                                                                        # extract islands
simpM<-simp[simp$entity_class=="Mainland",]                                                                                      # extract mainlands
simpI<-simpI[simpI$geology=="dev"|simpI$geology=="nondev",]                                                                      # extract only dev/nondev islands
simpI$elev_range[simpI$elev_range == 0]<- 1                                                                                      # make 0 elevations 1
simpI$elev_range[is.na(simpI$elev_range)] <- 1                                                                                   # make unknown elevations 1

# Join Island and Mainland, Rename entity_class2
simp<-rbind(simpI,simpM)
simp$entity_class2<-"mainland"
simp$entity_class2[simp$geology == "dev"]<- "oceanic"
simp$entity_class2[simp$geology == "nondev"]<-"nonoceanic"

# Add logcounts
simp$logcounts1<- log(simp$myc1+0.01)
simp$logcounts2<- log(simp$myc2+0.01)
simp$logcounts3<- log(simp$myc3+0.01)
simp$logcounts4<- log(simp$myc4+0.01)

# Remove zero occurences
simp<-simp[!(simp$myc1==0),]

# Create native and invasive versions
simpn<-simp[simp$native=="native",]
simpi<-simp[simp$native=="invasive",]

# Add species counts
species<-read.csv("data/MEGA2Species.csv", header=TRUE, sep=",")                # read data
species$X<-NULL                                                                 # remove col
species$status[species$native==1]<- "N"                                         # recode Native
species$status[species$naturalized==1]<- "I"                                    # recode Invasive
df<-as.data.frame(unique(species$entity_ID))                                    # extract unique locations

sprich<-tapply(species$entity_ID, list(species$entity_ID, species$status), sum) # group by entity class and sum
sprich<-as.data.frame(sprich)                                                   # change to dataframe
sprich$entity_ID<-rownames(sprich)                                              # add rownames sprich to col entity_ID

# Extract native and invasive counts, rename cols
sprichnat<-sprich[,c(2,3)]
sprichinv<-sprich[,c(1,3)]

colnames(sprichnat)<-c("sprich","entity_ID")
colnames(sprichinv)<-c("sprich","entity_ID")

# Extract myc type
simpn.AM<-simpn[simpn$myc=="AM",]
simpn.NM<-simpn[simpn$myc=="NM",]
simpi.AM<-simpi[simpi$myc=="AM",]
simpi.NM<-simpi[simpi$myc=="NM",]

# Merge by both entity_ID and native
simpn.spr.AM<-merge(simpn.AM,sprichnat, by="entity_ID", all.x=TRUE)
simpn.spr.NM<-merge(simpn.NM,sprichnat, by="entity_ID", all.x=TRUE)
simpn.spr<-rbind(simpn.spr.NM, simpn.spr.AM)

simpi.spr.AM<-merge(simpi.AM,sprichnat, by="entity_ID", all.x=TRUE)
simpi.spr.NM<-merge(simpi.NM,sprichnat, by="entity_ID", all.x=TRUE)
simpi.spr<-rbind(simpi.spr.NM, simpi.spr.AM)

# Transform and scale
simpn.spr$sprich <- scale(log10(simpn.spr$sprich+.01))
simpn.spr$area <-scale(log10((simpn.spr$area)+.01)) #log of area
simpn.spr$elev_range <- scale(log10(simpn.spr$elev_range+.01))
simpn.spr$abslatitude<-scale(abs(simpn.spr$latitude))

simpi.spr$sprich <- scale(log10(simpi.spr$sprich+.01))
simpi.spr$area <-scale(log10((simpi.spr$area)+.01)) #log of area
simpi.spr$elev_range <- scale(log10(simpi.spr$elev_range+.01))
simpi.spr$abslatitude<-scale(abs(simpi.spr$latitude))

#############################
#### AMNM1 BROAD NATIVE #####
#############################
m1N <- glmer(myc1~myc*entity_class2+abslatitude+area+elev_range+sprich+(1|entity_class2:entity_ID) +(1|entity_class2:entity_ID:myc),
             family = poisson, data = simpn.spr,glmerControl(optimizer = "bobyqa", optCtrl = list(maxfun = 100000))) 
summary(m1N) 

#############################
### AMNM1 BROAD INVASIVE ####
#############################
m1I <- glmer(myc1~myc*entity_class2 + sprich +latitude+area+elev_range+(1|entity_class2:entity_ID) +(1|entity_class2:entity_ID:myc),
             family = poisson, data = simpi.spr, glmerControl(optimizer = "bobyqa", optCtrl = list(maxfun = 100000))) 
summary(m1I) 

##############################
#### ENVIRONMENTAL MODELS ####
##############################

##########################
##### MAINLAND MODELS ####
##########################

# Prepare data
gdat<- read.table("data/Mega2_Drivers.AMvsNM.txt")                                                          # read data
gdat<- gdat[,c("entity_ID","mycNM1","mycAM1","mycNM2","mycAM2","mycNM3","mycAM3","mycNM4","mycAM4",  # take columns of interest
               "area","elev_range","entity_class","native","longitude","latitude",
               "CHELSA_annual_Prec","CHELSA_annual_mean_Temp","Popdensity")]
gdatM<-gdat[gdat$entity_class=="Mainland",]                                                          # extract mainlands

# Make gdat only mainlands:
gdat<-gdatM

# Remove zero occurences
gdat<-gdat[!(gdat$mycAM1==0 |gdat$mycNM1==0),]

# Transform and scale:
gdat$area <-scale(log10((gdat$area) + .01)) #log of area
gdat$elev_range <- scale(log10(gdat$elev_range+.01))
gdat$CHELSA_annual_mean_Temp<-scale(gdat$CHELSA_annual_mean_Temp)
gdat$CHELSA_annual_Prec<-scale(gdat$CHELSA_annual_Prec)
gdat$abslatitude<-scale(abs(gdat$latitude))
gdat$squaredlat<-scale(abs(gdat$latitude)^2)

# Create native and invasive versions
gdatMnat<-gdat[gdat$native=="native",]
gdatMin<-gdat[gdat$native=="invasive",]

gdatMnat<-na.omit(gdatMnat)
gdatMin<-na.omit(gdatMin)

##########################
##### MAINLAND NATIVE ####
##########################

AMNM1gdatMnat <- glm(cbind(gdatMnat$mycAM1,gdatMnat$mycNM1) ~ area + abslatitude+squaredlat+
                       CHELSA_annual_Prec +CHELSA_annual_mean_Temp +elev_range, data = gdatMnat, family = binomial(link="logit"))
summary(AMNM1gdatMnat)

# check overdispersion
N <- nrow(gdatMnat)
p <- length(coef(AMNM1gdatMnat))
E1 <- resid(AMNM1gdatMnat, type = "pearson")
Dispersion <- sum(E1^2)/ (N-p)

# apply quasibinomial
qAMNM1gdatMnat <- glm(cbind(gdatMnat$mycAM1,gdatMnat$mycNM1) ~ area +abslatitude+squaredlat+
                        CHELSA_annual_Prec +CHELSA_annual_mean_Temp +elev_range, data = gdatMnat, family = quasibinomial(link="logit"))

# account for spatial autocorrelation
coords <- cbind(gdatMnat$longitude, gdatMnat$latitude)
matrix.dist = as.matrix(dist(cbind(gdatMnat$longitude, gdatMnat$latitude)))
matrix.dist[1:10, 1:10]
matrix.dist.inv <- 1/matrix.dist
matrix.dist.inv[1:10, 1:10]
diag(matrix.dist.inv) <- 0
matrix.dist.inv[1:10, 1:10]
nonsp_moranI = Moran.I(resid(qAMNM1gdatMnat), matrix.dist.inv)
myDist = 1000
rac <- autocov_dist(resid(qAMNM1gdatMnat), coords, nbs = myDist, type = "inverse", zero.policy = TRUE, style = "W", longlat=T) # longlat=T interprets myDist = 300 as 300 km.

sp_qAMNM1gdatMnat <- glm(cbind(gdatMnat$mycAM1,gdatMnat$mycNM1)~  area+abslatitude+squaredlat+
                           CHELSA_annual_Prec +CHELSA_annual_mean_Temp+elev_range+ rac, data = gdatMnat, family = binomial(link="logit"))
summary(sp_qAMNM1gdatMnat) 

##########################
### MAINLAND INVASIVE ####
##########################

AMNM1gdatMin <- glm(cbind(gdatMin$mycAM1,gdatMin$mycNM1) ~ area + abslatitude+squaredlat+
                      CHELSA_annual_Prec +CHELSA_annual_mean_Temp +elev_range, data = gdatMin, family = binomial(link="logit"))
summary(AMNM1gdatMin)

# check overdispersion
N <- nrow(gdatMin)
p <- length(coef(AMNM1gdatMin))
E1 <- resid(AMNM1gdatMin, type = "pearson")
Dispersion <- sum(E1^2)/ (N-p)

# apply quasibinomial
qAMNM1gdatMin <- glm(cbind(gdatMin$mycAM1,gdatMin$mycNM1) ~ area +abslatitude+squaredlat+
                       CHELSA_annual_Prec +CHELSA_annual_mean_Temp +elev_range, data = gdatMin, family = quasibinomial(link="logit"))

# account for spatial autocorrelation
coords <- cbind(gdatMin$longitude, gdatMin$latitude)
matrix.dist = as.matrix(dist(cbind(gdatMin$longitude, gdatMin$latitude)))
matrix.dist[1:10, 1:10]
matrix.dist.inv <- 1/matrix.dist
matrix.dist.inv[1:10, 1:10]
diag(matrix.dist.inv) <- 0
matrix.dist.inv[1:10, 1:10]
nonsp_moranI = Moran.I(resid(qAMNM1gdatMin), matrix.dist.inv)
myDist = 1000
rac <- autocov_dist(resid(qAMNM1gdatMin), coords, nbs = myDist, type = "inverse", zero.policy = TRUE, style = "W", longlat=T) # longlat=T interprets myDist = 300 as 300 km.

sp_qAMNM1gdatMin <- glm(cbind(gdatMin$mycAM1,gdatMin$mycNM1)~  area+abslatitude+squaredlat+
                          CHELSA_annual_Prec +CHELSA_annual_mean_Temp+elev_range+ rac, data = gdatMin, family = binomial(link="logit"))
summary(sp_qAMNM1gdatMin) 

##########################
###### ISLAND MODELS #####
##########################

# Prepare data
gdat<- read.table("data/Mega2_Drivers.AMvsNM.txt")                                                                       # read data
gdat<- gdat[,c("entity_ID","mycNM1","mycAM1","mycNM2","mycAM2","mycNM3","mycAM3","mycNM4","mycAM4",               # take columns of interest
               "latitude","longitude","geology", "area","elev_range","dist","age_Ma","entity_class","native",
               "CHELSA_annual_Prec","CHELSA_annual_mean_Temp","Popdensity")]
gdatI<-gdat[gdat$entity_class=="Island",]                                                                         # extract islands
gdatM<-gdat[gdat$entity_class=="Mainland",]                                                                       # extract mainlands

gdatI<-gdatI[gdatI$geology=="dev",]                                                                               # keep only oceanic islands

gdatI$elev_range[gdatI$elev_range == 0]<- 1                                                                       # make 0 elevations 1
gdatI$elev_range[is.na(gdatI$elev_range)] <- 1                                                                    # make unknown elevations 1

# Make gdat only islands:
gdat<-gdatI

# Remove zero occurences
gdat<-gdat[!(gdat$mycNM1==0 |gdat$mycAM1==0),]

# Transform and scale
gdat$area <-scale(log10(gdat$area + .01)) #log of area
gdat$dist<-scale(gdat$dist)
gdat$elev_range <- scale(log10(gdat$elev_range+.01))
gdat$age_Ma <- scale(log10(gdat$age_Ma+.01))
gdat$CHELSA_annual_mean_Temp<-scale(gdat$CHELSA_annual_mean_Temp)
gdat$CHELSA_annual_Prec<-scale(gdat$CHELSA_annual_Prec)
gdat$abslatitude<-scale(abs(gdat$latitude))
gdat$squaredlat<-scale(abs(gdat$latitude)^2)

# Create native and invasive versions
gdatInat<-gdat[gdat$native=="native",]
gdatIin<-gdat[gdat$native=="invasive",]

gdatInat<-na.omit(gdatInat)
gdatIin<-na.omit(gdatIin)

##########################
###### ISLAND NATIVE #####
##########################

AMNM1gdatInat.noage <- glm(cbind(gdatInat$mycAM1,gdatInat$mycNM1) ~  area +  dist+CHELSA_annual_Prec +abslatitude+squaredlat+
                             CHELSA_annual_mean_Temp +elev_range, data = gdatInat, family = binomial(link="logit"))
summary(AMNM1gdatInat.noage) 

# check overdispersion
N <- nrow(gdatInat)
p <- length(coef(AMNM1gdatInat.noage))
E1 <- resid(AMNM1gdatInat.noage, type = "pearson")
Dispersion <- sum(E1^2)/ (N-p)

# apply quasibinomial
qAMNM1gdatInat.noage <- glm(cbind(gdatInat$mycAM1,gdatInat$mycNM1) ~   area + dist+ CHELSA_annual_Prec+abslatitude+squaredlat+
                              CHELSA_annual_mean_Temp +elev_range, data = gdatInat, family = quasibinomial(link="logit"))
summary(qAMNM1gdatInat.noage) 
# account for spatial autocorrelation
coords <- cbind(gdatInat$longitude, gdatInat$latitude)
matrix.dist = as.matrix(dist(cbind(gdatInat$longitude, gdatInat$latitude)))
matrix.dist[1:10, 1:10]
matrix.dist.inv <- 1/matrix.dist
matrix.dist.inv[1:10, 1:10]
diag(matrix.dist.inv) <- 0
matrix.dist.inv[1:10, 1:10]
nonsp_moranI = Moran.I(resid(qAMNM1gdatInat.noage), matrix.dist.inv)
myDist = 1000
rac <- autocov_dist(resid(qAMNM1gdatInat.noage), coords, nbs = myDist, type = "inverse", zero.policy = TRUE, style = "W", longlat=T) # longlat=T interprets myDist = 300 as 300 km.
sp_qAMNM1gdatInat.noage <- glm(cbind(gdatInat$mycAM1,gdatInat$mycNM1)~  area + dist+ CHELSA_annual_Prec+abslatitude+squaredlat+
                                 CHELSA_annual_mean_Temp +elev_range+ rac, data = gdatInat, family = binomial(link="logit"))
summary(sp_qAMNM1gdatInat.noage)

##########################
#### ISLAND INVASIVE #####
##########################

AMNM1gdatIin.noage <- glm(cbind(gdatIin$mycAM1,gdatIin$mycNM1) ~  area +  dist+CHELSA_annual_Prec +abslatitude+squaredlat+
                            CHELSA_annual_mean_Temp +elev_range, data = gdatIin, family = binomial(link="logit"))
summary(AMNM1gdatIin.noage) 

# check overdispersion
N <- nrow(gdatIin)
p <- length(coef(AMNM1gdatIin.noage))
E1 <- resid(AMNM1gdatIin.noage, type = "pearson")
Dispersion <- sum(E1^2)/ (N-p)

# apply quasibinomial
qAMNM1gdatIin.noage <- glm(cbind(gdatIin$mycAM1,gdatIin$mycNM1) ~   area + dist+ CHELSA_annual_Prec+abslatitude+squaredlat+
                             CHELSA_annual_mean_Temp +elev_range, data = gdatIin, family = quasibinomial(link="logit"))
summary(qAMNM1gdatIin.noage) 
# account for spatial autocorrelation
coords <- cbind(gdatIin$longitude, gdatIin$latitude)
matrix.dist = as.matrix(dist(cbind(gdatIin$longitude, gdatIin$latitude)))
matrix.dist[1:10, 1:10]
matrix.dist.inv <- 1/matrix.dist
matrix.dist.inv[1:10, 1:10]
diag(matrix.dist.inv) <- 0
matrix.dist.inv[1:10, 1:10]
nonsp_moranI = Moran.I(resid(qAMNM1gdatIin.noage), matrix.dist.inv)
myDist = 1000
rac <- autocov_dist(resid(qAMNM1gdatIin.noage), coords, nbs = myDist, type = "inverse", zero.policy = TRUE, style = "W", longlat=T) # longlat=T interprets myDist = 300 as 300 km.
sp_qAMNM1gdatIin.noage <- glm(cbind(gdatIin$mycAM1,gdatIin$mycNM1)~  area + dist+ CHELSA_annual_Prec+abslatitude+squaredlat+
                                CHELSA_annual_mean_Temp +elev_range+ rac, data = gdatIin, family = binomial(link="logit"))
summary(sp_qAMNM1gdatIin.noage)

##########################
##########################
########## ORC/NM ########
##########################
##########################

##########################
###### BROAD MODELS ######
##########################

# Prepare data
simp<- read.table("data/Mega2_Broadcomp2&3.ORCvsNM.txt", header=TRUE)                                                                    # read data
simp<- simp[,c("entity_ID","myc1","latitude","geology", "area","elev_range","entity_class","native","myc")] # take columns of interest
simp<-simp[!simp$entity_class == "undetermined",]                                                                                # remove all undetermined entity_class/land types
simpI<-simp[simp$entity_class=="Island",]                                                                                        # extract islands
simpM<-simp[simp$entity_class=="Mainland",]                                                                                      # extract mainlands
simpI<-simpI[simpI$geology=="dev"|simpI$geology=="nondev",]                                                                      # extract only dev/nondev islands
simpI$elev_range[simpI$elev_range == 0]<- 1                                                                                      # make 0 elevations 1
simpI$elev_range[is.na(simpI$elev_range)] <- 1                                                                                   # make unknown elevations 1

# Join Island and Mainland, Rename entity_class2
simp<-rbind(simpI,simpM)
simp$entity_class2<-"mainland"
simp$entity_class2[simp$geology == "dev"]<- "oceanic"
simp$entity_class2[simp$geology == "nondev"]<-"nonoceanic"

# Add logcounts
simp$logcounts1<- log(simp$myc1+0.01)

# Remove zero occurences
simp<-simp[!(simp$myc1==0 & simp$myc=="MYC"),]

# Create native and invasive versions
simpn<-simp[simp$native=="native",]
simpi<-simp[simp$native=="invasive",]

# Add species counts
species<-read.csv("data/MEGA2Species.csv", header=TRUE, sep=",")                # read data
species$X<-NULL                                                                 # remove col
species$status[species$native==1]<- "N"                                         # recode Native
species$status[species$naturalized==1]<- "I"                                    # recode Invasive
df<-as.data.frame(unique(species$entity_ID))                                    # extract unique locations

sprich<-tapply(species$entity_ID, list(species$entity_ID, species$status), sum) # group by entity class and sum
sprich<-as.data.frame(sprich)                                                   # change to dataframe
sprich$entity_ID<-rownames(sprich)                                              # add rownames sprich to col entity_ID

# Extract native and invasive counts, rename cols
sprichnat<-sprich[,c(2,3)]
sprichinv<-sprich[,c(1,3)]

colnames(sprichnat)<-c("sprich","entity_ID")
colnames(sprichinv)<-c("sprich","entity_ID")

# Extract myc type
simpn.ORC<-simpn[simpn$myc=="ORC",]
simpn.NM<-simpn[simpn$myc=="NM",]
simpi.ORC<-simpi[simpi$myc=="ORC",]
simpi.NM<-simpi[simpi$myc=="NM",]

# Merge by both entity_ID and native
simpn.spr.ORC<-merge(simpn.ORC,sprichnat, by="entity_ID", all.x=TRUE)
simpn.spr.NM<-merge(simpn.NM,sprichnat, by="entity_ID", all.x=TRUE)
simpn.spr<-rbind(simpn.spr.NM, simpn.spr.ORC)

simpi.spr.ORC<-merge(simpi.ORC,sprichnat, by="entity_ID", all.x=TRUE)
simpi.spr.NM<-merge(simpi.NM,sprichnat, by="entity_ID", all.x=TRUE)
simpi.spr<-rbind(simpi.spr.NM, simpi.spr.ORC)

# Transform and scale
simpn.spr$sprich <- scale(log10(simpn.spr$sprich+.01))
simpn.spr$area <-scale(log10((simpn.spr$area)+.01)) #log of area
simpn.spr$elev_range <- scale(log10(simpn.spr$elev_range+.01))
simpn.spr$abslatitude<-scale(abs(simpn.spr$latitude))

simpi.spr$sprich <- scale(log10(simpi.spr$sprich+.01))
simpi.spr$area <-scale(log10((simpi.spr$area)+.01)) #log of area
simpi.spr$elev_range <- scale(log10(simpi.spr$elev_range+.01))
simpi.spr$abslatitude<-scale(abs(simpi.spr$latitude))

#############################
#### ORCNM1 BROAD NATIVE #####
#############################
m1N <- glmer(myc1~myc*entity_class2+abslatitude+area+elev_range+sprich+(1|entity_class2:entity_ID) +(1|entity_class2:entity_ID:myc),
             family = poisson, data = simpn.spr,glmerControl(optimizer = "bobyqa", optCtrl = list(maxfun = 100000))) 
summary(m1N) 

#############################
### ORCNM1 BROAD INVASIVE ####
#############################
m1I <- glmer(myc1~myc*entity_class2 + sprich +latitude+area+elev_range+(1|entity_class2:entity_ID) +(1|entity_class2:entity_ID:myc),
             family = poisson, data = simpi.spr, glmerControl(optimizer = "bobyqa", optCtrl = list(maxfun = 100000))) 
summary(m1I) 

##############################
#### ENVIRONMENTAL MODELS ####
##############################

##########################
##### MAINLAND MODELS ####
##########################

# Prepare data
gdat<- read.table("data/Mega2_Drivers.ORCvsNM.txt")                                                  # read data
gdat<- gdat[,c("entity_ID","mycNM1","mycORC1",                                                       # take columns of interest
               "area","elev_range","entity_class","native","longitude","latitude",
               "CHELSA_annual_Prec","CHELSA_annual_mean_Temp","Popdensity")]
gdatM<-gdat[gdat$entity_class=="Mainland",]                                                          # extract mainlands

# Make gdat only mainlands:
gdat<-gdatM

# Remove zero occurences
gdat<-gdat[!(gdat$mycORC1==0 |gdat$mycNM1==0),]

# Transform and scale:
gdat$area <-scale(log10((gdat$area) + .01)) #log of area
gdat$elev_range <- scale(log10(gdat$elev_range+.01))
gdat$CHELSA_annual_mean_Temp<-scale(gdat$CHELSA_annual_mean_Temp)
gdat$CHELSA_annual_Prec<-scale(gdat$CHELSA_annual_Prec)
gdat$abslatitude<-scale(abs(gdat$latitude))
gdat$squaredlat<-scale(abs(gdat$latitude)^2)

# Create native and invasive versions
gdatMnat<-gdat[gdat$native=="native",]
gdatMin<-gdat[gdat$native=="invasive",]

gdatMnat<-na.omit(gdatMnat)
gdatMin<-na.omit(gdatMin)

##########################
##### MAINLAND NATIVE ####
##########################

ORCNM1gdatMnat <- glm(cbind(gdatMnat$mycORC1,gdatMnat$mycNM1) ~ area + abslatitude+squaredlat+
                       CHELSA_annual_Prec +CHELSA_annual_mean_Temp +elev_range, data = gdatMnat, family = binomial(link="logit"))
summary(ORCNM1gdatMnat)

# check overdispersion
N <- nrow(gdatMnat)
p <- length(coef(ORCNM1gdatMnat))
E1 <- resid(ORCNM1gdatMnat, type = "pearson")
Dispersion <- sum(E1^2)/ (N-p)

# apply quasibinomial
qORCNM1gdatMnat <- glm(cbind(gdatMnat$mycORC1,gdatMnat$mycNM1) ~ area +abslatitude+squaredlat+
                        CHELSA_annual_Prec +CHELSA_annual_mean_Temp +elev_range, data = gdatMnat, family = quasibinomial(link="logit"))

# account for spatial autocorrelation
coords <- cbind(gdatMnat$longitude, gdatMnat$latitude)
matrix.dist = as.matrix(dist(cbind(gdatMnat$longitude, gdatMnat$latitude)))
matrix.dist[1:10, 1:10]
matrix.dist.inv <- 1/matrix.dist
matrix.dist.inv[1:10, 1:10]
diag(matrix.dist.inv) <- 0
matrix.dist.inv[1:10, 1:10]
nonsp_moranI = Moran.I(resid(qORCNM1gdatMnat), matrix.dist.inv)
myDist = 1000
rac <- autocov_dist(resid(qORCNM1gdatMnat), coords, nbs = myDist, type = "inverse", zero.policy = TRUE, style = "W", longlat=T) # longlat=T interprets myDist = 300 as 300 km.

sp_qORCNM1gdatMnat <- glm(cbind(gdatMnat$mycORC1,gdatMnat$mycNM1)~  area+abslatitude+squaredlat+
                           CHELSA_annual_Prec +CHELSA_annual_mean_Temp+elev_range+ rac, data = gdatMnat, family = binomial(link="logit"))
summary(sp_qORCNM1gdatMnat) 

##########################
### MAINLAND INVASIVE ####
##########################

ORCNM1gdatMin <- glm(cbind(gdatMin$mycORC1,gdatMin$mycNM1) ~ area + abslatitude+squaredlat+
                      CHELSA_annual_Prec +CHELSA_annual_mean_Temp +elev_range, data = gdatMin, family = binomial(link="logit"))
summary(ORCNM1gdatMin)

# check overdispersion
N <- nrow(gdatMin)
p <- length(coef(ORCNM1gdatMin))
E1 <- resid(ORCNM1gdatMin, type = "pearson")
Dispersion <- sum(E1^2)/ (N-p)

# apply quasibinomial
qORCNM1gdatMin <- glm(cbind(gdatMin$mycORC1,gdatMin$mycNM1) ~ area +abslatitude+squaredlat+
                       CHELSA_annual_Prec +CHELSA_annual_mean_Temp +elev_range, data = gdatMin, family = quasibinomial(link="logit"))

# account for spatial autocorrelation
coords <- cbind(gdatMin$longitude, gdatMin$latitude)
matrix.dist = as.matrix(dist(cbind(gdatMin$longitude, gdatMin$latitude)))
matrix.dist[1:10, 1:10]
matrix.dist.inv <- 1/matrix.dist
matrix.dist.inv[1:10, 1:10]
diag(matrix.dist.inv) <- 0
matrix.dist.inv[1:10, 1:10]
nonsp_moranI = Moran.I(resid(qORCNM1gdatMin), matrix.dist.inv)
myDist = 1000
rac <- autocov_dist(resid(qORCNM1gdatMin), coords, nbs = myDist, type = "inverse", zero.policy = TRUE, style = "W", longlat=T) # longlat=T interprets myDist = 300 as 300 km.

sp_qORCNM1gdatMin <- glm(cbind(gdatMin$mycORC1,gdatMin$mycNM1)~  area+abslatitude+squaredlat+
                          CHELSA_annual_Prec +CHELSA_annual_mean_Temp+elev_range+ rac, data = gdatMin, family = binomial(link="logit"))
summary(sp_qORCNM1gdatMin) 

##########################
###### ISLAND MODELS #####
##########################

# Prepare data
gdat<- read.table("data/Mega2_Drivers.ORCvsNM.txt")                                                                       # read data
gdat<- gdat[,c("entity_ID","mycNM1","mycORC1",                                                                            # take columns of interest
               "latitude","longitude","geology", "area","elev_range","dist","age_Ma","entity_class","native",
               "CHELSA_annual_Prec","CHELSA_annual_mean_Temp","Popdensity")]
gdatI<-gdat[gdat$entity_class=="Island",]                                                                         # extract islands
gdatM<-gdat[gdat$entity_class=="Mainland",]                                                                       # extract mainlands

gdatI<-gdatI[gdatI$geology=="dev",]                                                                               # keep only oceanic islands

gdatI$elev_range[gdatI$elev_range == 0]<- 1                                                                       # make 0 elevations 1
gdatI$elev_range[is.na(gdatI$elev_range)] <- 1                                                                    # make unknown elevations 1

# Make gdat only islands:
gdat<-gdatI

# Remove zero occurences
gdat<-gdat[!(gdat$mycNM1==0 |gdat$mycORC1==0),]

# Transform and scale
gdat$area <-scale(log10(gdat$area + .01)) #log of area
gdat$dist<-scale(gdat$dist)
gdat$elev_range <- scale(log10(gdat$elev_range+.01))
gdat$age_Ma <- scale(log10(gdat$age_Ma+.01))
gdat$CHELSA_annual_mean_Temp<-scale(gdat$CHELSA_annual_mean_Temp)
gdat$CHELSA_annual_Prec<-scale(gdat$CHELSA_annual_Prec)
gdat$abslatitude<-scale(abs(gdat$latitude))
gdat$squaredlat<-scale(abs(gdat$latitude)^2)

# Create native and invasive versions
gdatInat<-gdat[gdat$native=="native",]
gdatIin<-gdat[gdat$native=="invasive",]

gdatInat<-na.omit(gdatInat)
gdatIin<-na.omit(gdatIin)

##########################
###### ISLAND NATIVE #####
##########################

ORCNM1gdatInat.noage <- glm(cbind(gdatInat$mycORC1,gdatInat$mycNM1) ~  area +  dist+CHELSA_annual_Prec +abslatitude+squaredlat+
                             CHELSA_annual_mean_Temp +elev_range, data = gdatInat, family = binomial(link="logit"))
summary(ORCNM1gdatInat.noage) 

# check overdispersion
N <- nrow(gdatInat)
p <- length(coef(ORCNM1gdatInat.noage))
E1 <- resid(ORCNM1gdatInat.noage, type = "pearson")
Dispersion <- sum(E1^2)/ (N-p)

# apply quasibinomial
qORCNM1gdatInat.noage <- glm(cbind(gdatInat$mycORC1,gdatInat$mycNM1) ~   area + dist+ CHELSA_annual_Prec+abslatitude+squaredlat+
                              CHELSA_annual_mean_Temp +elev_range, data = gdatInat, family = quasibinomial(link="logit"))
summary(qORCNM1gdatInat.noage) 
# account for spatial autocorrelation
coords <- cbind(gdatInat$longitude, gdatInat$latitude)
matrix.dist = as.matrix(dist(cbind(gdatInat$longitude, gdatInat$latitude)))
matrix.dist[1:10, 1:10]
matrix.dist.inv <- 1/matrix.dist
matrix.dist.inv[1:10, 1:10]
diag(matrix.dist.inv) <- 0
matrix.dist.inv[1:10, 1:10]
nonsp_moranI = Moran.I(resid(qORCNM1gdatInat.noage), matrix.dist.inv)
myDist = 1000
rac <- autocov_dist(resid(qORCNM1gdatInat.noage), coords, nbs = myDist, type = "inverse", zero.policy = TRUE, style = "W", longlat=T) # longlat=T interprets myDist = 300 as 300 km.
sp_qORCNM1gdatInat.noage <- glm(cbind(gdatInat$mycORC1,gdatInat$mycNM1)~  area + dist+ CHELSA_annual_Prec+abslatitude+squaredlat+
                                 CHELSA_annual_mean_Temp +elev_range+ rac, data = gdatInat, family = binomial(link="logit"))
summary(sp_qORCNM1gdatInat.noage)

##########################
#### ISLAND INVASIVE #####
##########################

ORCNM1gdatIin.noage <- glm(cbind(gdatIin$mycORC1,gdatIin$mycNM1) ~  area +  dist+CHELSA_annual_Prec +abslatitude+squaredlat+
                            CHELSA_annual_mean_Temp +elev_range, data = gdatIin, family = binomial(link="logit"))
summary(ORCNM1gdatIin.noage) 

# check overdispersion
N <- nrow(gdatIin)
p <- length(coef(ORCNM1gdatIin.noage))
E1 <- resid(ORCNM1gdatIin.noage, type = "pearson")
Dispersion <- sum(E1^2)/ (N-p)

# apply quasibinomial
qORCNM1gdatIin.noage <- glm(cbind(gdatIin$mycORC1,gdatIin$mycNM1) ~   area + dist+ CHELSA_annual_Prec+abslatitude+squaredlat+
                             CHELSA_annual_mean_Temp +elev_range, data = gdatIin, family = quasibinomial(link="logit"))
summary(qORCNM1gdatIin.noage) 
# account for spatial autocorrelation
coords <- cbind(gdatIin$longitude, gdatIin$latitude)
matrix.dist = as.matrix(dist(cbind(gdatIin$longitude, gdatIin$latitude)))
matrix.dist[1:10, 1:10]
matrix.dist.inv <- 1/matrix.dist
matrix.dist.inv[1:10, 1:10]
diag(matrix.dist.inv) <- 0
matrix.dist.inv[1:10, 1:10]
nonsp_moranI = Moran.I(resid(qORCNM1gdatIin.noage), matrix.dist.inv)
myDist = 1000
rac <- autocov_dist(resid(qORCNM1gdatIin.noage), coords, nbs = myDist, type = "inverse", zero.policy = TRUE, style = "W", longlat=T) # longlat=T interprets myDist = 300 as 300 km.
sp_qORCNM1gdatIin.noage <- glm(cbind(gdatIin$mycORC1,gdatIin$mycNM1)~  area + dist+ CHELSA_annual_Prec+abslatitude+squaredlat+
                                CHELSA_annual_mean_Temp +elev_range+ rac, data = gdatIin, family = binomial(link="logit"))
summary(sp_qORCNM1gdatIin.noage)

##########################
##########################
########## ORC/M #########
##########################
##########################

##########################
###### BROAD MODELS ######
##########################

# Prepare data
simp<- read.table("data/Mega2ORC_Broadcomp2&3.txt", header=TRUE)                                                                    # read data
simp<- simp[,c("entity_ID","myc1","myc2","latitude","geology", "area","elev_range","entity_class","native","myc")] # take columns of interest
simp<-simp[!simp$entity_class == "undetermined",]                                                                                # remove all undetermined entity_class/land types
simpI<-simp[simp$entity_class=="Island",]                                                                                        # extract islands
simpM<-simp[simp$entity_class=="Mainland",]                                                                                      # extract mainlands
simpI<-simpI[simpI$geology=="dev"|simpI$geology=="nondev",]                                                                      # extract only dev/nondev islands
simpI$elev_range[simpI$elev_range == 0]<- 1                                                                                      # make 0 elevations 1
simpI$elev_range[is.na(simpI$elev_range)] <- 1                                                                                   # make unknown elevations 1

# Join Island and Mainland, Rename entity_class2
simp<-rbind(simpI,simpM)
simp$entity_class2<-"mainland"
simp$entity_class2[simp$geology == "dev"]<- "oceanic"
simp$entity_class2[simp$geology == "nondev"]<-"nonoceanic"

# Add logcounts
simp$logcounts1<- log(simp$myc1+1)
simp$logcounts2<- log(simp$myc2+1)

# Remove zero occurences
simp<-simp[!(simp$myc1==0 & simp$myc=="MYC"),]

# Create native and invasive versions
simpn<-simp[simp$native=="native",]
simpi<-simp[simp$native=="invasive",]

# Add species counts
species<-read.csv("data/MEGA2Species.csv", header=TRUE, sep=",")                # read data
species$X<-NULL                                                                 # remove col
species$status[species$native==1]<- "N"                                         # recode Native
species$status[species$naturalized==1]<- "I"                                    # recode Invasive
df<-as.data.frame(unique(species$entity_ID))                                    # extract unique locations

sprich<-tapply(species$entity_ID, list(species$entity_ID, species$status), sum) # group by entity class and sum
sprich<-as.data.frame(sprich)                                                   # change to dataframe
sprich$entity_ID<-rownames(sprich)                                              # add rownames sprich to col entity_ID

# Extract native and invasive counts, rename cols
sprichnat<-sprich[,c(2,3)]
sprichinv<-sprich[,c(1,3)]

colnames(sprichnat)<-c("sprich","entity_ID")
colnames(sprichinv)<-c("sprich","entity_ID")

# Extract myc type
simpn.ORC<-simpn[simpn$myc=="ORC",]
simpn.M<-simpn[simpn$myc=="M",]
simpi.ORC<-simpi[simpi$myc=="ORC",]
simpi.M<-simpi[simpi$myc=="M",]

# Merge by both entity_ID and native
simpn.spr.ORC<-merge(simpn.ORC,sprichnat, by="entity_ID", all.x=TRUE)
simpn.spr.M<-merge(simpn.M,sprichnat, by="entity_ID", all.x=TRUE)
simpn.spr<-rbind(simpn.spr.M, simpn.spr.ORC)

simpi.spr.ORC<-merge(simpi.ORC,sprichnat, by="entity_ID", all.x=TRUE)
simpi.spr.M<-merge(simpi.M,sprichnat, by="entity_ID", all.x=TRUE)
simpi.spr<-rbind(simpi.spr.M, simpi.spr.ORC)

# Transform and scale
simpn.spr$sprich <- scale(log10(simpn.spr$sprich+.01))
simpn.spr$area <-scale(log10((simpn.spr$area)+.01)) #log of area
simpn.spr$elev_range <- scale(log10(simpn.spr$elev_range+.01))
simpn.spr$abslatitude<-scale(abs(simpn.spr$latitude))

simpi.spr$sprich <- scale(log10(simpi.spr$sprich+.01))
simpi.spr$area <-scale(log10((simpi.spr$area)+.01)) #log of area
simpi.spr$elev_range <- scale(log10(simpi.spr$elev_range+.01))
simpi.spr$abslatitude<-scale(abs(simpi.spr$latitude))

#############################
#### ORCM1 BROAD NATIVE #####
#############################
m1N <- glmer(myc1~myc*entity_class2+abslatitude+area+elev_range+sprich+(1|entity_class2:entity_ID) +(1|entity_class2:entity_ID:myc),
             family = poisson, data = simpn.spr,glmerControl(optimizer = "bobyqa", optCtrl = list(maxfun = 100000))) 
summary(m1N) 

#############################
### ORCM1 BROAD INVASIVE ####
#############################
m1I <- glmer(myc1~myc*entity_class2 + sprich +latitude+area+elev_range+(1|entity_class2:entity_ID) +(1|entity_class2:entity_ID:myc),
             family = poisson, data = simpi.spr, glmerControl(optimizer = "bobyqa", optCtrl = list(maxfun = 100000))) 
summary(m1I) 

##############################
#### ENVIRONMENTAL MODELS ####
##############################

##########################
##### MAINLAND MODELS ####
##########################

# Prepare data
gdat<- read.table("data/Mega2ORC_Drivers.txt")                                                   # read data
gdat<- gdat[,c("entity_ID","mycORC","mycM1","mycORC2","mycM2",                                   # take columns of interest
               "area","elev_range","entity_class","native","longitude","latitude",
               "CHELSA_annual_Prec","CHELSA_annual_mean_Temp","Popdensity")]
gdatM<-gdat[gdat$entity_class=="Mainland",]                                                      # extract mainlands

# Make gdat only mainlands:
gdat<-gdatM

# Remove zero occurences
gdat<-gdat[!(gdat$mycM1==0|gdat$mycORC ==0),]

# Transform and scale:
gdat$area <-scale(log10((gdat$area) + .01)) #log of area
gdat$elev_range <- scale(log10(gdat$elev_range+.01))
gdat$CHELSA_annual_mean_Temp<-scale(gdat$CHELSA_annual_mean_Temp)
gdat$CHELSA_annual_Prec<-scale(gdat$CHELSA_annual_Prec)
gdat$abslatitude<-scale(abs(gdat$latitude))
gdat$squaredlat<-scale(abs(gdat$latitude)^2)

# Create native and invasive versions
gdatMnat<-gdat[gdat$native=="native",]
gdatMin<-gdat[gdat$native=="invasive",]

gdatMnat<-na.omit(gdatMnat)
gdatMin<-na.omit(gdatMin)

##########################
##### MAINLAND NATIVE ####
##########################

ORCM1gdatMnat <- glm(cbind(gdatMnat$mycORC,gdatMnat$mycM1) ~ area + abslatitude+squaredlat+
                        CHELSA_annual_Prec +CHELSA_annual_mean_Temp +elev_range, data = gdatMnat, family = binomial(link="logit"))
summary(ORCM1gdatMnat)

# check overdispersion
N <- nrow(gdatMnat)
p <- length(coef(ORCM1gdatMnat))
E1 <- resid(ORCM1gdatMnat, type = "pearson")
Dispersion <- sum(E1^2)/ (N-p)

# apply quasibinomial
qORCM1gdatMnat <- glm(cbind(gdatMnat$mycORC,gdatMnat$mycM1) ~ area +abslatitude+squaredlat+
                         CHELSA_annual_Prec +CHELSA_annual_mean_Temp +elev_range, data = gdatMnat, family = quasibinomial(link="logit"))

# account for spatial autocorrelation
coords <- cbind(gdatMnat$longitude, gdatMnat$latitude)
matrix.dist = as.matrix(dist(cbind(gdatMnat$longitude, gdatMnat$latitude)))
matrix.dist[1:10, 1:10]
matrix.dist.inv <- 1/matrix.dist
matrix.dist.inv[1:10, 1:10]
diag(matrix.dist.inv) <- 0
matrix.dist.inv[1:10, 1:10]
nonsp_moranI = Moran.I(resid(qORCM1gdatMnat), matrix.dist.inv)
myDist = 1000
rac <- autocov_dist(resid(qORCM1gdatMnat), coords, nbs = myDist, type = "inverse", zero.policy = TRUE, style = "W", longlat=T) # longlat=T interprets myDist = 300 as 300 km.

sp_qORCM1gdatMnat <- glm(cbind(gdatMnat$mycORC,gdatMnat$mycM1)~  area+abslatitude+squaredlat+
                            CHELSA_annual_Prec +CHELSA_annual_mean_Temp+elev_range+ rac, data = gdatMnat, family = binomial(link="logit"))
summary(sp_qORCM1gdatMnat) 

##########################
### MAINLAND INVASIVE ####
##########################

ORCM1gdatMin <- glm(cbind(gdatMin$mycORC,gdatMin$mycM1) ~ area + abslatitude+squaredlat+
                       CHELSA_annual_Prec +CHELSA_annual_mean_Temp +elev_range, data = gdatMin, family = binomial(link="logit"))
summary(ORCM1gdatMin)

# check overdispersion
N <- nrow(gdatMin)
p <- length(coef(ORCM1gdatMin))
E1 <- resid(ORCM1gdatMin, type = "pearson")
Dispersion <- sum(E1^2)/ (N-p)

# apply quasibinomial
qORCM1gdatMin <- glm(cbind(gdatMin$mycORC,gdatMin$mycM1) ~ area +abslatitude+squaredlat+
                        CHELSA_annual_Prec +CHELSA_annual_mean_Temp +elev_range, data = gdatMin, family = quasibinomial(link="logit"))

# account for spatial autocorrelation
coords <- cbind(gdatMin$longitude, gdatMin$latitude)
matrix.dist = as.matrix(dist(cbind(gdatMin$longitude, gdatMin$latitude)))
matrix.dist[1:10, 1:10]
matrix.dist.inv <- 1/matrix.dist
matrix.dist.inv[1:10, 1:10]
diag(matrix.dist.inv) <- 0
matrix.dist.inv[1:10, 1:10]
nonsp_moranI = Moran.I(resid(qORCM1gdatMin), matrix.dist.inv)
myDist = 1000
rac <- autocov_dist(resid(qORCM1gdatMin), coords, nbs = myDist, type = "inverse", zero.policy = TRUE, style = "W", longlat=T) # longlat=T interprets myDist = 300 as 300 km.

sp_qORCM1gdatMin <- glm(cbind(gdatMin$mycORC,gdatMin$mycM1)~  area+abslatitude+squaredlat+
                           CHELSA_annual_Prec +CHELSA_annual_mean_Temp+elev_range+ rac, data = gdatMin, family = binomial(link="logit"))
summary(sp_qORCM1gdatMin) 

##########################
###### ISLAND MODELS #####
##########################

# Prepare data
gdat<- read.table("data/Mega2ORC_Drivers.txt")                                                                       # read data
gdat<- gdat[,c("entity_ID","mycORC","mycM1","mycORC2","mycM2",                                                                         # take columns of interest
               "latitude","longitude","geology", "area","elev_range","dist","age_Ma","entity_class","native",
               "CHELSA_annual_Prec","CHELSA_annual_mean_Temp","Popdensity")]
gdatI<-gdat[gdat$entity_class=="Island",]                                                                         # extract islands
gdatM<-gdat[gdat$entity_class=="Mainland",]                                                                       # extract mainlands

gdatI<-gdatI[gdatI$geology=="dev",]                                                                               # keep only oceanic islands

gdatI$elev_range[gdatI$elev_range == 0]<- 1                                                                       # make 0 elevations 1
gdatI$elev_range[is.na(gdatI$elev_range)] <- 1                                                                    # make unknown elevations 1

# Make gdat only islands:
gdat<-gdatI

# Remove zero occurences
gdat<-gdat[!(gdat$mycM1==0 |gdat$mycORC==0),]

# Transform and scale
gdat$area <-scale(log10(gdat$area + .01)) #log of area
gdat$dist<-scale(gdat$dist)
gdat$elev_range <- scale(log10(gdat$elev_range+.01))
gdat$age_Ma <- scale(log10(gdat$age_Ma+.01))
gdat$CHELSA_annual_mean_Temp<-scale(gdat$CHELSA_annual_mean_Temp)
gdat$CHELSA_annual_Prec<-scale(gdat$CHELSA_annual_Prec)
gdat$abslatitude<-scale(abs(gdat$latitude))
gdat$squaredlat<-scale(abs(gdat$latitude)^2)

# Create native and invasive versions
gdatInat<-gdat[gdat$native=="native",]
gdatIin<-gdat[gdat$native=="invasive",]

gdatInat<-na.omit(gdatInat)
gdatIin<-na.omit(gdatIin)

##########################
###### ISLAND NATIVE #####
##########################

ORCM1gdatInat.noage <- glm(cbind(gdatInat$mycORC,gdatInat$mycM1) ~  area +  dist+CHELSA_annual_Prec +abslatitude+squaredlat+
                              CHELSA_annual_mean_Temp +elev_range, data = gdatInat, family = binomial(link="logit"))
summary(ORCM1gdatInat.noage) 

# check overdispersion
N <- nrow(gdatInat)
p <- length(coef(ORCM1gdatInat.noage))
E1 <- resid(ORCM1gdatInat.noage, type = "pearson")
Dispersion <- sum(E1^2)/ (N-p)

# apply quasibinomial
qORCM1gdatInat.noage <- glm(cbind(gdatInat$mycORC,gdatInat$mycM1) ~   area + dist+ CHELSA_annual_Prec+abslatitude+squaredlat+
                               CHELSA_annual_mean_Temp +elev_range, data = gdatInat, family = quasibinomial(link="logit"))
summary(qORCM1gdatInat.noage) 
# account for spatial autocorrelation
coords <- cbind(gdatInat$longitude, gdatInat$latitude)
matrix.dist = as.matrix(dist(cbind(gdatInat$longitude, gdatInat$latitude)))
matrix.dist[1:10, 1:10]
matrix.dist.inv <- 1/matrix.dist
matrix.dist.inv[1:10, 1:10]
diag(matrix.dist.inv) <- 0
matrix.dist.inv[1:10, 1:10]
nonsp_moranI = Moran.I(resid(qORCM1gdatInat.noage), matrix.dist.inv)
myDist = 1000
rac <- autocov_dist(resid(qORCM1gdatInat.noage), coords, nbs = myDist, type = "inverse", zero.policy = TRUE, style = "W", longlat=T) # longlat=T interprets myDist = 300 as 300 km.
sp_qORCM1gdatInat.noage <- glm(cbind(gdatInat$mycORC,gdatInat$mycM1)~  area + dist+ CHELSA_annual_Prec+abslatitude+squaredlat+
                                  CHELSA_annual_mean_Temp +elev_range+ rac, data = gdatInat, family = binomial(link="logit"))
summary(sp_qORCM1gdatInat.noage)

##########################
#### ISLAND INVASIVE #####
##########################

ORCM1gdatIin.noage <- glm(cbind(gdatIin$mycORC,gdatIin$mycM1) ~  area +  dist+CHELSA_annual_Prec +abslatitude+squaredlat+
                             CHELSA_annual_mean_Temp +elev_range, data = gdatIin, family = binomial(link="logit"))
summary(ORCM1gdatIin.noage) 

# check overdispersion
N <- nrow(gdatIin)
p <- length(coef(ORCM1gdatIin.noage))
E1 <- resid(ORCM1gdatIin.noage, type = "pearson")
Dispersion <- sum(E1^2)/ (N-p)

# apply quasibinomial
qORCM1gdatIin.noage <- glm(cbind(gdatIin$mycORC,gdatIin$mycM1) ~   area + dist+ CHELSA_annual_Prec+abslatitude+squaredlat+
                              CHELSA_annual_mean_Temp +elev_range, data = gdatIin, family = quasibinomial(link="logit"))
summary(qORCM1gdatIin.noage) 
# account for spatial autocorrelation
coords <- cbind(gdatIin$longitude, gdatIin$latitude)
matrix.dist = as.matrix(dist(cbind(gdatIin$longitude, gdatIin$latitude)))
matrix.dist[1:10, 1:10]
matrix.dist.inv <- 1/matrix.dist
matrix.dist.inv[1:10, 1:10]
diag(matrix.dist.inv) <- 0
matrix.dist.inv[1:10, 1:10]
nonsp_moranI = Moran.I(resid(qORCM1gdatIin.noage), matrix.dist.inv)
myDist = 1000
rac <- autocov_dist(resid(qORCM1gdatIin.noage), coords, nbs = myDist, type = "inverse", zero.policy = TRUE, style = "W", longlat=T) # longlat=T interprets myDist = 300 as 300 km.
sp_qORCM1gdatIin.noage <- glm(cbind(gdatIin$mycORC,gdatIin$mycM1)~  area + dist+ CHELSA_annual_Prec+abslatitude+squaredlat+
                                 CHELSA_annual_mean_Temp +elev_range+ rac, data = gdatIin, family = binomial(link="logit"))
summary(sp_qORCM1gdatIin.noage)